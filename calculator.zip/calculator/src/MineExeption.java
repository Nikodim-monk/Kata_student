public class MineExeption extends Exception{
    public MineExeption (String str){
        super(str);
    }
}
